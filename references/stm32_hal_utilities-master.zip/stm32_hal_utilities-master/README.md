# STM32 HAL Utilities
A collection of useful utilities to use in conjunction with STM32 HAL Driver
