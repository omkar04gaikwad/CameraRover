Release v0.1.0 
BLinky LED configs done using GUI and application done using HAL codes. 