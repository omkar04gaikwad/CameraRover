/*
 * gimbal_stuff.h
 *
 *  Created on: Aug 13, 2020
 *      Author: deshp
 */

#ifndef INC_GIMBAL_STUFF_H_
#define INC_GIMBAL_STUFF_H_


#include "../../Libs/mavlink/include/mavlink_types.h"
#include "../../Libs/mavlink/include/mavlink.h"

void init_gimbal();

#endif /* INC_GIMBAL_STUFF_H_ */
